create definer = rdsadmin@localhost event ev_rds_gsh_collector on schedule
    every '5' MINUTE
        starts '2024-05-07 18:39:04'
    on completion preserve
    disable
    do
    CALL rds_collect_global_status_history();

