create definer = rdsadmin@localhost event ev_rds_gsh_table_rotation on schedule
    every '7' DAY
        starts '2024-06-06 08:04:16'
    on completion preserve
    disable
    do
    CALL rds_rotate_global_status_history();

