create
    definer = rdsadmin@localhost function rds_version() returns varchar(30) deterministic sql security invoker no sql
BEGIN
RETURN '8.0.36.R2';
END;

